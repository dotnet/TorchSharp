class LanguageModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  blockSize : int
  vocabSize : int
  layers : __torch__.torch.nn.modules.container.___torch_mangle_4.Sequential
  def forward(self: __torch__.llm.LanguageModel,
    input: Tensor) -> Tensor:
    layers = self.layers
    return (layers).forward(input, )
class EmbeddingModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  positions : Tensor
  tok_emb : __torch__.torch.nn.modules.sparse.Embedding
  pos_emb : __torch__.torch.nn.modules.sparse.___torch_mangle_0.Embedding
  def forward(self: __torch__.llm.EmbeddingModel,
    input: Tensor) -> Tensor:
    tok_emb = self.tok_emb
    tok_emb0 = (tok_emb).forward(input, )
    pos_emb = self.pos_emb
    positions = self.positions
    pos_emb0 = (pos_emb).forward(positions, )
    return torch.add(tok_emb0, pos_emb0)
class Block(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  ln1 : __torch__.torch.nn.modules.normalization.LayerNorm
  attn : __torch__.llm.CausalSelfAttention
  ln2 : __torch__.torch.nn.modules.normalization.LayerNorm
  mlp : __torch__.llm.MLP
  def forward(self: __torch__.llm.Block,
    xs: Tensor) -> Tensor:
    ln1 = self.ln1
    xs0 = (ln1).forward(xs, )
    attn = self.attn
    attn0 = (attn).forward(xs0, )
    xs1 = torch.add(xs0, attn0)
    ln2 = self.ln2
    ln20 = (ln2).forward(xs1, )
    mlp = self.mlp
    xs2 = (mlp).forward(xs1, )
    return torch.add(xs2, ln20)
class CausalSelfAttention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dropout : float
  nHeads : int
  c_attn : __torch__.torch.nn.modules.linear.Linear
  resid_dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.llm.CausalSelfAttention,
    xs: Tensor) -> Tensor:
    B, T, C, = torch.size(xs)
    c_attn = self.c_attn
    _0 = (c_attn).forward(xs, )
    nHeads = self.nHeads
    _1 = torch.mul(nHeads, 3)
    nHeads0 = self.nHeads
    _2 = [B, T, _1, torch.floordiv(C, nHeads0)]
    _3 = torch.transpose(torch.view(_0, _2), 1, 2)
    nHeads1 = self.nHeads
    q, k, v, = torch.split(_3, nHeads1, 1)
    dropout = self.dropout
    y = torch.scaled_dot_product_attention(q, k, v, None, dropout, True)
    _4 = torch.contiguous(torch.transpose(y, 1, 2))
    y0 = torch.view(_4, torch.size(xs))
    resid_dropout = self.resid_dropout
    return (resid_dropout).forward(y0, )
class MLP(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encodingSize : int
  net : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.llm.MLP,
    xs: Tensor) -> Tensor:
    net = self.net
    return (net).forward(xs, )
