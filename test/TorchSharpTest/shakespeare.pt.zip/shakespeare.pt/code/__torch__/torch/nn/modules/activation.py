class GELU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  approximate : Final[str] = "none"
  def forward(self: __torch__.torch.nn.modules.activation.GELU,
    input: Tensor) -> Tensor:
    return torch.gelu(input)
