class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  embed : __torch__.llm.EmbeddingModel
  block1 : __torch__.llm.Block
  block2 : __torch__.llm.Block
  de_embed : __torch__.torch.nn.modules.linear.___torch_mangle_3.Linear
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_4.Sequential,
    input: Tensor) -> Tensor:
    embed = self.embed
    block1 = self.block1
    block2 = self.block2
    de_embed = self.de_embed
    input0 = (embed).forward(input, )
    input1 = (block1).forward(input0, )
    input2 = (block2).forward(input1, )
    return (de_embed).forward(input2, )
  def __len__(self: __torch__.torch.nn.modules.container.___torch_mangle_4.Sequential) -> int:
    return 4
